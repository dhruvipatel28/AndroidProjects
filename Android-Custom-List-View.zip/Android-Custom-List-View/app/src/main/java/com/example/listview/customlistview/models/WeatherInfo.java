package com.example.listview.customlistview.models;

public class WeatherInfo {
    private String name, atmo , temp;
    private int photo;

    public WeatherInfo(){}

    public WeatherInfo(String name, String atmo, int photo, String temp) {
        this.name = name;
        this.atmo = atmo;
        this.photo = photo;
        this.temp = temp;
    }

    public String getName() {
        return name;
    }

    public String getAtmo() {
        return atmo;
    }

    public String getTemp() {
        return temp;
    }

    public int getPhoto() {
        return photo;
    }
}
