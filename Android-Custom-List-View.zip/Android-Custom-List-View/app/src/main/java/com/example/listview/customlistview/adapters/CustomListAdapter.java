package com.example.listview.customlistview.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.listview.customlistview.R;
import com.example.listview.customlistview.activities.MainActivity;
import com.example.listview.customlistview.models.WeatherInfo;

import java.util.ArrayList;

public class CustomListAdapter extends BaseAdapter implements View.OnClickListener{
    private ArrayList<WeatherInfo> weatherInfos;
    private Context context;

    public CustomListAdapter(ArrayList<WeatherInfo> weatherInfos, Context context) {
        this.weatherInfos = weatherInfos;
        this.context = context;
    }

    @Override
    public int getCount() {
        return weatherInfos.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater layoutInflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        view=layoutInflater.inflate(R.layout.custom_list_view_layout,null);
        ImageView photo,option;
        if(view==null){
            photo=new ImageView(context);
        }
        WeatherInfo weatherInfo = weatherInfos.get(i);

        photo=(ImageView)view.findViewById(R.id.photo);
        option=(ImageView)view.findViewById(R.id.next);
        TextView name=(TextView)view.findViewById(R.id.name);
        TextView temprature=(TextView)view.findViewById(R.id.temprature);
        TextView profession=(TextView)view.findViewById(R.id.atmo);

        photo.setImageResource(weatherInfo.getPhoto());
        name.setText(weatherInfo.getName());
        profession.setText(weatherInfo.getAtmo());
        temprature.setText(weatherInfo.getTemp());
        option.setOnClickListener(this);
        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.next:

                break;
        }
    }



    //file search result
    public void filterResult(ArrayList<WeatherInfo> newWeatherInfos){
        weatherInfos =new ArrayList<>();
        weatherInfos.addAll(newWeatherInfos);
        notifyDataSetChanged();
    }
}
