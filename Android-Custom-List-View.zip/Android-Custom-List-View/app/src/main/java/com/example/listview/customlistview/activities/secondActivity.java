package com.example.listview.customlistview.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.listview.customlistview.R;

public class secondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Intent intent = getIntent();
        String value = intent.getStringExtra("key");

        TextView tv = (TextView) findViewById(R.id.name);
        tv.setText(value);
    }

    @Override
    public void onBackPressed() {
        this.finish();
    }
}
