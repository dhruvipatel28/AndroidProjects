package com.example.listview.customlistview.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.listview.customlistview.R;
import com.example.listview.customlistview.adapters.CustomListAdapter;
import com.example.listview.customlistview.models.WeatherInfo;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<WeatherInfo> weatherInfos;
    private CustomListAdapter customListAdapter;
    private ListView customListView;

    private String[] names={
            "Berlin", "Bangalore" ,"London"," New York" , "Sydney",
            "Montreal" ,"Toronto" , "Vancouver" ,"Calgary" ,"Chicago"
    };
    private String[] atmo={
            "Snowing" ," Thunderstorms" , "Rainy" , "Cloudy" ,"Sunny",
            "Snowing" ," Thunderstorms" , "Rainy" , "Cloudy" ,"Sunny"
    };
    private int[] photos={
            R.drawable.sample_5,R.drawable.sample_1,R.drawable.sample_6,R.drawable.sample_5,R.drawable.sample_5,
            R.drawable.sample_0,R.drawable.sample_2,R.drawable.sample_3,R.drawable.sample_5,R.drawable.sample_2,
            R.drawable.sample_6,R.drawable.sample_1,R.drawable.sample_4,R.drawable.sample_6,R.drawable.sample_4,
            R.drawable.sample_0,R.drawable.sample_3,R.drawable.sample_3,R.drawable.sample_5,R.drawable.sample_4,
            R.drawable.sample_7,R.drawable.sample_1,R.drawable.sample_5,R.drawable.sample_5,R.drawable.sample_0
    };

    private String[] temrature={
            "0°" , "23°C", "5°C", "18°C", "32°C",
            "3°" , "13°C", "15°C", "-8°C", "-2°C"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setSupportActionBar((Toolbar)findViewById(R.id.toolbar));
        customListView=(ListView)findViewById(R.id.custom_list_view);
        weatherInfos =new ArrayList<>();
        customListAdapter=new CustomListAdapter(weatherInfos,this);
        customListView.setAdapter(customListAdapter);
        customListAdapter.notifyDataSetChanged();
        getDatas();
        customListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l)
            {
                Toast.makeText(MainActivity.this, "Name : " + names[i] + "\n Atmosphere : " + atmo[i] + "\n Temperature is : " + temrature[i], Toast.LENGTH_SHORT).show();
                String  s = "Name : " + names[i] + "\n Atmosphere : " + atmo[i] + "\n Temperature is : " + temrature[i] ;
                startActivity(new Intent(getApplicationContext() , secondActivity.class));
                Intent myIntent = new Intent(MainActivity.this, secondActivity.class);
                myIntent.putExtra("key", s);
                MainActivity.this.startActivity(myIntent);

            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        customListAdapter.notifyDataSetChanged();
    }

    // getting all the datas
    private void getDatas(){
        for(int count=0;count<names.length;count++){
            weatherInfos.add(new WeatherInfo(names[count],atmo[count] ,photos[count], temrature[count]));
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.search_option,menu);
        MenuItem menuItem=menu.findItem(R.id.search);
        SearchView searchView=(SearchView)menuItem.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                newText=newText.toString();
                ArrayList<WeatherInfo> newWeatherInfos =new ArrayList<>();
                for(WeatherInfo weatherInfo : weatherInfos){
                    String name= weatherInfo.getName().toLowerCase();
                    String profession= weatherInfo.getAtmo().toLowerCase();
                    if(name.contains(newText) || profession.contains(newText)){
                        newWeatherInfos.add(weatherInfo);
                    }
                }
                customListAdapter.filterResult(newWeatherInfos);
                customListAdapter.notifyDataSetChanged();
                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }
}
