package com.example.macstudent.androidfinalexamc0719320;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.speech.RecognizerIntent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;


import android.telephony.SmsManager;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import org.json.JSONObject;

public class HomeActivity extends AppCompatActivity
{

    EditText phone;
    Button btnSend , btnShow;
    TextView txt;
    String Speech , num;
    private PermissionListener sendSMSPermissionListener;



    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        phone = (EditText)findViewById(R.id.editText);
        btnSend = (Button) findViewById(R.id.btnsms);
        btnShow = (Button) findViewById(R.id.btnshowme);
        txt = (TextView) findViewById(R.id.txt);


        createPermissionListener();


        Dexter.withActivity(HomeActivity.this)
                .withPermission(Manifest.permission.SEND_SMS)
                .withListener(sendSMSPermissionListener)
                .check();



        btnSend.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Speech = "";

                startSpeechRecognizer();


                num = phone.getText().toString();


               // send();
            }
        });

        btnShow.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Speech = "";
                String inputLine = "", result = "";

                String lat = " ", longi = " ";

                startSpeechRecognizer();


                String myUrl="https://maps.googleapis.com/maps/api/geocode/json?address=" +Speech +"&key=AIzaSyCz-xx_QIiXnApK6moJUqH-OnBjexHQQzo";
                try
                {
                    URL url=new URL(myUrl);
                    URLConnection urlConnection=url.openConnection();
                    BufferedReader in = new BufferedReader(new
                            InputStreamReader(urlConnection.getInputStream()));
                    while ((inputLine = in.readLine()) != null) {
                        result=inputLine;
                    }

                    Log.e("" , result);

                    lat = result.substring(6, result.lastIndexOf(","));
                    longi = result.substring(result.lastIndexOf(",") + 1);



                    Log.e( " Lat Long  " , lat + " " + longi);

                    Intent intent = new Intent(getBaseContext(), MapsActivity.class);
                    intent.putExtra("lat", lat);
                    intent.putExtra("long", longi);
                    intent.putExtra("place", Speech);
                    startActivity(intent);
                }
                catch(Exception e){
                    e.printStackTrace();
                }



            }
        });

    }//on cre


    public void createPermissionListener() {
        if (sendSMSPermissionListener == null) {
            sendSMSPermissionListener = new PermissionListener() {
                @Override
                public void onPermissionGranted(PermissionGrantedResponse response) {
                    // permission was granted.

                }

                @Override
                public void onPermissionDenied(PermissionDeniedResponse response) {
                    // you don't have permissions
                }

                @Override
                public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {
                    // run this if the person pressed deny the first time
                    token.continuePermissionRequest();


                }
            };
        }
    }




    private void startSpeechRecognizer()
    {

        // this is the default microphone popup box
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);

        // SETUP NONSENSE: the next two lines are all setup nonsense
        // you can also do: "EXTRA_LANGUAGE_MODEL, en-us" for a specific locale
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);

        // configure the message on the microphone popup box
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "What color is the sky?");

        try {
            // show the popup box
            startActivityForResult(intent, 30);
        }
        catch (ActivityNotFoundException a) {
            // Sometimes you are using a phone that doesn't have speech to text functions
            // If this happens, then show error message.
            String msg = "Your phone doesn't support speech to text.";
            Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 30) {
            if (resultCode == RESULT_OK) {

                // get results from speech recognizer and save to a list / array
                List<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

                // get the first item in the list -> this is what
                // google thinks the person said
                String answer = results.get(0);

                txt.setText("You said: " + answer);

                Log.e( "  Phone Number : " + phone.getText().toString() , " Message : " + txt.getText().toString());
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage("6475684535",null ,answer , null, null);
                Speech = answer;


                if (answer.indexOf("blue") > -1)
                    Toast.makeText(this, "You win!", Toast.LENGTH_SHORT).show();
                else {
                    Toast.makeText(this, "Wrong!", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }



}
