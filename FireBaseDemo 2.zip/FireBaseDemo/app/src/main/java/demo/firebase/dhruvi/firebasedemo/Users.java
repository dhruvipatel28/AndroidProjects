package demo.firebase.dhruvi.firebasedemo;

public class Users
{

    public String name;
    public String email;


    public Users()
    {

    }

    public Users(String name, String email)
    {
        this.name = name;
        this.email = email;
    }
}
