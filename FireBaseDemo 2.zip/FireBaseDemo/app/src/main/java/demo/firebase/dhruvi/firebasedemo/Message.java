package demo.firebase.dhruvi.firebasedemo;

public class Message
{


    public String name;
    public String message;
    public String date;

    // constructors
    public Message()
    {
        // leave this constructor empty
    }

    public Message(String n, String m, String d)
    {
        this.name = n;
        this.message = m;
        this.date = d;
    }

}
