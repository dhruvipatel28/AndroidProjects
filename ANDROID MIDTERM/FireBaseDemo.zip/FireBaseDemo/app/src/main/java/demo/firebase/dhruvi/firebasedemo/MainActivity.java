package demo.firebase.dhruvi.firebasedemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity
{

    FirebaseDatabase fb;
    DatabaseReference ref;
    Button btn;
    EditText txtmsg;
    String url;
    String text;

    private ChildEventListener childEventListener;

    RequestQueue RQ;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn = findViewById(R.id.btn);
        txtmsg = findViewById(R.id.editText);
        url = "https://api.coindesk.com/v1/bpi/currentprice/";

        //set up firebase

        fb = FirebaseDatabase.getInstance();
        ref = fb.getReference();

        //attachedMessageEL();




        // create insert data

        //Users uObj = new Users("Dhruvi", "DhruviPatel");
        //ref.child("tblUser").push().setValue(uObj);


        btn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Date d = new Date();
                SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a");
                String date = sdf.format(d);
                url = "https://api.coindesk.com/v1/bpi/currentprice/";
                text = txtmsg.getText().toString().trim();
                if(!text.isEmpty())
                {
                    url = url + text +".json";
                    callJson();

                }
            }
        });




    } // oncreate


    public void callJson()
    {
        Log.e("-----------",  url);
        if(RQ == null)
        {
            RQ = Volley.newRequestQueue(getApplicationContext());
        }


        JsonObjectRequest JR;
        JR = new JsonObjectRequest(
                Request.Method.GET,
                url,
                null,
                new Response.Listener<JSONObject>()
                {
                    @Override
                    public void onResponse(JSONObject response)
                    {
                        Log.e("-----",response.toString());
                        try
                        {
                            JSONObject jsonBpi =  response.getJSONObject("bpi");
                            JSONObject mainJs = jsonBpi.getJSONObject(text);

                            String price = mainJs.getString("rate");
                            String time = response.getJSONObject("time").getString("updatedISO");

                            Log.e( "---- --  Price ", mainJs.getString("rate")  );
                            Log.e( "---- --  Date ", time );
                            Log.e( "---- --  Currency Code ", text  );

                            abc abcObj = new abc(price,time,text);
                            ref.child("abc").push().setValue(abcObj);

                        }//
                        catch(JSONException e){ Log.e("-----","error there" + e.toString() );}


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error)
                    {
                        Log.e("-----",error.toString());
                        //Message m = dataSnapshot.getValue(Message.class);
                        //String txt = m.date + ": " + m.name + " says: " + m.message + "\n";
                    }
                }


        );

        RQ.add(JR);
    }//callJSon



}
