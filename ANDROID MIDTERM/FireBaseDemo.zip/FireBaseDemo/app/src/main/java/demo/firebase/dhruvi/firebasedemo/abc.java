package demo.firebase.dhruvi.firebasedemo;

public class abc
{


    public String price;
    public String date;
    public String currCode;

    // constructors
    public abc()
    {
        // leave this constructor empty
    }

    public abc(String price, String date, String currCode)
    {
        this.price = price;
        this.date = date;
        this.currCode = currCode;
    }
}
